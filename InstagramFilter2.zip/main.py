from PIL import Image
import random

def getRed(pixel):
    return pixel[0]

def getGreen(pixel):
    return pixel[1]

def getBlue(pixel):
    return pixel[2]

def moreRed(pixel):
  #print ("reddddddddd")
  new_red = getRed(pixel) + 100
  new_green = getGreen(pixel)
  new_blue = getBlue(pixel)
  new_pixel = (new_red, new_green, new_blue)
  return new_pixel

def moreGreen(pixel):
  new_red = getRed(pixel)
  new_green = getGreen(pixel) + 100
  new_blue = getBlue(pixel)
  new_pixel = (new_red, new_green, new_blue)
  return new_pixel

def moreBlue(pixel):                              
  new_red = getRed(pixel)
  new_green = getGreen(pixel)
  new_blue = getBlue(pixel) + 100
  new_pixel = (new_red, new_green, new_blue)
  return new_pixel

def increase(pixel):
  new_red = getRed(pixel) + 40
  new_green = getGreen(pixel) + 40
  new_blue = getBlue(pixel) + 40
  new_pixel = (new_red, new_green, new_blue)
  return new_pixel

def grayscale(pixel):
  new_red = getRed(pixel) + 40
  new_green = getRed(pixel) + 40
  new_blue = getRed(pixel) + 40
  new_pixel = (new_red, new_green, new_blue)
  return new_pixel

print("AGGIE PRIDE")
jack = Image.open("nini.jpg")

new_pixels = []
num_pixels = len(jack.getdata())
pixels = jack.getdata()
print (num_pixels)
for i in range(0, num_pixels, 1):
  ## top half
  if i % 120000 < 60000:
    new_pixel = moreBlue(pixels[i])
  ## lower half
  else:
    new_pixel = (pixels[i])
  new_pixels.append(new_pixel)

new_image = Image.new("RGB", jack.size)
new_image.putdata(new_pixels)
new_image.save("nini2.jpg", "JPEG")

print("done")

# print ("hello")
#   if getBlue(pixels[i]) > 60 and getRed(pixels[i]) < 100 and getGreen(pixels[i]) < 100: 
#     new_pixel = (200, 200, 200)
#   else:
#     new_pixel = pixels[i]
#   ## top half
#   if i < num_pixels / 2:
#     new_pixel = moreBlue(pixels[i])
#   ## lower half
#   else:
#     new_pixel = moreRed(pixels[i])

  # ## top half
  # if i < num_pixels / 2:
  #   new_pixel = moreBlue(pixels[i])
  # ## lower half
  # else:
  #   new_pixel = moreRed(pixels[i])
  # new_pixels.append(new_pixel)

# for i in range(0,num_pixels,1):
#   if getRed(pixels[i]) > 100:
#     new_pixel = pixels[i] 
#   else:
#     new_pixel = grey(pixels[i])

#   new_pixels.append(new_pixel)