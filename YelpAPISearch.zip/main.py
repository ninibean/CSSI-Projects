from __future__ import print_function

import argparse
import json
import pprint
import requests
import sys
import urllib


from urllib2 import HTTPError
from urllib import quote
from urllib import urlencode


# Yelp Fusion no longer uses OAuth as of December 7, 2017.
# You no longer need to provide Client ID to fetch Data
# It now uses private keys to authenticate requests (API Key)
# You can find it on
# https://www.yelp.com/developers/v3/manage_app
API_KEY= 'zOb4TW8iDULwjdLuxeAntmjiQN-5LzSmfB4JK9oYRsfGzsKeWfJE3F7a5csWAsF9jlgztfU10WzMylqhB7-sVO3taS3Xc0BTYPY9FTGdVC-hom2tXImDQfD0APVQW3Yx'


# API constants, you shouldn't have to change these.
API_HOST = 'https://api.yelp.com'
SEARCH_PATH = '/v3/businesses/search'
BUSINESS_PATH = '/v3/businesses/'  # Business ID will come after slash.


# Defaults for our simple example.
DEFAULT_TERM = 'dinner'
DEFAULT_LOCATION = 'San Francisco, CA'
SEARCH_LIMIT = 3


def request(host, path, api_key, url_params=None):
  """Given your API_KEY, send a GET request to the API.
  Args:
    host (str): The domain host of the API.
    path (str): The path of the API after the domain.
    API_KEY (str): Your API Key.
    url_params (dict): An optional set of query parameters in the request.
  Returns:
    dict: The JSON response from the request.
  Raises:
    HTTPError: An error occurs from the HTTP request.
  """
  url_params = url_params or {}
  url = '{0}{1}'.format(host, quote(path.encode('utf8')))
  headers = {
    'Authorization': 'Bearer %s' % api_key,
  }

  print(u'Querying {0} ...'.format(url))

  response = requests.request('GET', url, headers=headers, params=url_params)

  return response.json()


def search(api_key, term, location, price): #, address):
  """Query the Search API by a search term and location.
  Args:
    term (str): The search term passed to the API.
    location (str): The search location passed to the API.
  Returns:
    dict: The JSON response from the request.
  """

  url_params = {
    'term': term.replace(' ', '+'),
    'location': location.replace(' ', '+'),
    'limit': SEARCH_LIMIT,
    'price': price,
    #'address' : address,
  }
  return request(API_HOST, SEARCH_PATH, api_key, url_params=url_params)


def get_business(api_key, business_id):
  """Query the Business API by a business ID.
  Args:
    business_id (str): The ID of the business to query.
  Returns:
    dict: The JSON response from the request.
  """
  business_path = BUSINESS_PATH + business_id

  return request(API_HOST, business_path, api_key)


def query_api(term, location):
    """Queries the API by the input values from the user.
    Args:
      term (str): The search term to query.
      location (str): The location of the business to query.
    """
    response = search(API_KEY, term, location)

    businesses = response.get('businesses')

    if not businesses:
      print(u'No businesses for {0} in {1} found.'.format(term, location))
      return

    business_id = businesses[0]['id']

    print(u'{0} businesses found, querying business info ' \
      'for the top result "{1}" ...'.format(
        len(businesses), business_id))
    response = get_business(API_KEY, business_id)

    print(u'Result for business "{0}" found:'.format(business_id))
    pprint.pprint(response, indent=2)

# # 0. pizza place in chicago?
# result = search(API_KEY,"pizza", "chicago")
# print ("0. pizza in chicago")
# list_of_pizza_places = result['businesses']
# pizza_place_dictionary = list_of_pizza_places[0]
# print(pizza_place_dictionary['name'])

# # 1. What is the top result for sushi in New York?
# result = search(API_KEY,"sushi", "New York")
# print ("1. sushi in New York")
# list_of_sushi_places = result['businesses']
# sushi_place_dictionary = list_of_sushi_places[0]
# print(sushi_place_dictionary['name'])

# # 2. What is the top result for tacos in Seattle?
# result = search(API_KEY,"tacos", "Seattle")
# print ("2. tacos in Seattle")
# list_of_taco_places = result['businesses']
# taco_place_dictionary = list_of_taco_places[0]
# print(taco_place_dictionary['name'])

# # 3. What is the 3rd result for pasta in Naples?
# result = search(API_KEY,"pasta", "Naples")
# print ("3. pasta in Naples")
# list_of_pasta_places = result['businesses']
# pasta_place_dictionary = list_of_pasta_places[2]
# print(pasta_place_dictionary['name'])

# 4. How many “$” does the varsity in Atlanta have?
result = search(API_KEY,"The Varsity", "Atlanta", "1")
print ("4. The Varisty in Atlanta")
the_varsity = result['businesses']
varsity_place_dictionary = the_varsity[0]
print(varsity_place_dictionary["id"])

# 5. What is the address of a Burger King in New Orleans?
# result = search(API_KEY,"Burger King", "New Orleans", "1")
# print ("5. Burger King in New Orleans")
# burger_king = result['businesses']
# burger_king_dictionary = burger_king[0]
# print(burger_king_dictionary['address'])