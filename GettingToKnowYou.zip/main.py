name = raw_input ("Please enter your name.")

print ("Hi there, " + name + "!")
numLetters = len(name)
#print (numLetters)

hobby = raw_input ("So tell me , " + name + ", what is one of your favorite hobbies?")
numLetters = len(hobby)
#print (numLetters)
if numLetters > 8:
  print ("That's really cool!")
else:
  print ("Hey, I do that too! :)")

fave_food = raw_input ("What is your favorite food?")
numLetters = len(fave_food)
#print (numLetters)
if numLetters > 5:
  print ("Mmm, sounds delicious!")
else:
  print ("That sounds good, but computers can't eat human food, so i don't know what that tastes like. :(")

zodiac = raw_input ("What's your zodiac sign?")
numLetters = len(zodiac)
if numLetters == 6:
  print ("Oh my gosh! Me too!")
else:
  print ("Cool! I have a bunch of freinds who are " + zodiac + "'s!")

game = raw_input ("Why don't we play a game? Rock, paper or scissors?")
if game == "Scissors" or "scissors":
  print ("BOOM! Rock beats scissors! I win!")
else:
  if game == "Paper" or "paper":
   print ("Oh no! You got me! Paper beats rock! You win!")
else:
  raw_input ("Silly! " + game + " doesn't beat rock! Try again! Rock, paper, or scissors?")