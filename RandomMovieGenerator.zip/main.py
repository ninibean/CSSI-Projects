import random

title_beginning = [
  "The Misadventures of ",
  "The Adventures of ",
  "Werewolves and ",
  "God Forbid, She Touched the ",
  "Honey, There is ",
  "Tales of ",
  "Revenge of the ",
  "Take the ",
  "The Book of ",
  "The Blood of ",
]

title_ending = [
  "Lemonade: The Return of the Killer Lemons, ",
  "Death, ", 
  "The Lonely Spirit, ",
  "Dill Pickle and Nochoe Cheezie, ",
  "Life of Her, ",
  "The Giant Butt and other Poopy Tales, ",
  "Satan, ",
  "Sharkeisha, ",
  "Sammy the Talking Smelly Shoe, ",
  "Vampires who Love Garlic ",
]

action = [
  "starring ",
  "directed by ",
  "insipred by the book by ",
  "based on a true story by ",
  "as told by ",
]

actor = [
  "Angela Basset",
  "Michael Jackson",
  "Donald Glover",
  "Pickle Rick",
  "Blue from Blues Clues",
  "The Wiggles",
  "Gary the Snail", 
  "Naruto",
  "Dwayne 'The Rock' Johnson",
  "Samuel Jackson",
]

for movie_title in range (1, 11, 1):
  title_choice1 = random.choice(title_beginning)
  title_choice2 = random.choice(title_ending)
  action_choice = random.choice(action)
  actor_choice = random.choice(actor)
  print (title_choice1 + title_choice2 + action_choice + actor_choice)
